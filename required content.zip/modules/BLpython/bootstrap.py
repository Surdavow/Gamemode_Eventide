#Load mods
#Imported in C++ as file_load_py_main
#Automatically copied into modules/BLPython/bootstrap.py if file does not already exist
#This file can be edited without being overwritten. It can be deleted if it needs to be restored.

#todo: catch module exceptions (will quit program if a module has an exception

#
# Modified to work with folders as well as ZIP files.
#

import BLpython, sys, os, traceback, zipfile, zipimport
import importlib.util

import site
site.main()

path = os.path.join(os.getcwd(), 'modules', 'BLpython')
extractSuffix = '_EXTRACT'

def printException():
	BLpython.BlPrint('[ Python Exception ]')
	BLpython.BlPrint(traceback.format_exc())

def getAllFolderModules():
	dirs = set()
	for dir in os.listdir(path):
		mod_directory = os.path.join(path, dir)
		base_name = os.path.splitext(os.path.basename(dir))[0]
		if zipfile.is_zipfile(mod_directory) and base_name.endswith(extractSuffix):
			try:
				with zipfile.ZipFile(mod_directory, mode='r') as mod:
					BLpython.BlPrint(f'      [ Extracting ZIP file: \'{dir}\' ]')
					mod.extractall(path)
					try:
						os.remove(mod_directory)
					except OSError:
						BLpython.BlPrint(f'      [ Could not remove extracted ZIP file: \'{dir}\' ]')
						pass
				dirs.add(base_name.removesuffix(extractSuffix))
			except:
				printException()
		elif not os.path.isdir(mod_directory) or not os.path.isfile(os.path.join(mod_directory, '__init__.py')):
			continue
		else:
			dirs.add(dir)
	return dirs

def loadFromFolders():
	if not path in sys.path:
		sys.path.insert(0, path)
	for dir in getAllFolderModules():
		try:
			BLpython.BlPrint(f'      [ Importing folder: \'{dir}\' ]')
			sys.path.insert(0, os.path.join(path, dir))
			importlib.import_module(dir)
		except:
			printException()

def getAllZipModules():
	zips = set()
	for zip in os.listdir(path):
		zip_directory = os.path.join(path, zip)
		if not os.path.isfile(zip_directory) or not zipfile.is_zipfile(zip_directory) or os.path.splitext(os.path.basename(zip_directory))[0].endswith(extractSuffix):
			continue
		try:
			with zipfile.ZipFile(zip_directory, mode='r') as mod:
				for file_dir in mod.namelist():
					if file_dir.endswith('__init__.py'):
						zips.add(zip)
		except:
			printException()
	return zips

def loadFromZipModules():
	if not path in sys.path:
		sys.path.insert(0, path)
	for zip in getAllZipModules():
		try:
			BLpython.BlPrint(f'      [ Importing ZIP file: \'{zip}\' ]')
			importer = zipimport.zipimporter(os.path.join(path, zip))
			importer.load_module(os.path.splitext(zip)[0])
		except:
			printException()

def reloadModule(obj=None, args=None):
	try:
		BLpython.BlPrint(f'      [ Reloading module: \'{args[1]}\' ]')
		for module_name, module_object in sys.modules.items():
			if module_name.lower() == args[1]:
				importlib.reload(module_object)
				break
	except:
		printException()
	return
BLpython.TSregisterFunc(None, None, "py_reload_module", reloadModule, None, "Reloads a Python module from the modules/BLpython folder.", 1, 2)

def reloadAllModules(obj=None, args=None):
	for module_name, module_object in sys.modules.items():
		try:
			BLpython.BlPrint(f'      [ Reloading module: \'{module_name}\' ]')
			importlib.reload(module_object)
		except:
			printException()
	return
BLpython.TSregisterFunc(None, None, "py_reload_module_all", reloadAllModules, None, "Reloads all Python modules from the modules/BLpython folder.", 1, 1)

#Startup.
def init():
	loadFromFolders()
	loadFromZipModules()

try:
	init()
except:
	printException()
