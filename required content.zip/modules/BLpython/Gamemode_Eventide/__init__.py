import BLpython, wave, os, math, pyogg

def getWavLength(obj=None, args=None):
    try:
        blocklandDirectory = os.getcwd()
        filePath = os.path.join(blocklandDirectory, args[1]) #The first argument to a BLpython function is the function name itself. Don't know why, ask Queuenard.
        
        with wave.open(filePath, mode='rb') as waveFile:
            sampleRate = waveFile.getframerate()
            numberOfFrames = waveFile.getnframes()
            lengthInSeconds = numberOfFrames / sampleRate
            
            millisecondsRounded = math.ceil(lengthInSeconds * 1000) #Returns a float.
            return int(millisecondsRounded) #Convert it to an integer.
    except Exception as e:
        BLpython.BlPrint(str(e))
    return -1
BLpython.TSregisterFunc(None, None, "getWavLength", getWavLength, int, "Gets the millisecond length of a WAV sound file.", 2, 2)

def getOggLength(obj=None, args=None):
    try:
        blocklandDirectory = os.getcwd()
        filePath = os.path.join(blocklandDirectory, args[1])

        oggFile = pyogg.VorbisFile(filePath)

        byteSize = oggFile.buffer_length
        bytesPerSample = 2 #This function only supports 16-bit audio.
        channels = oggFile.channels
        sampleRate = oggFile.frequency
        lengthInSeconds = byteSize / (channels * sampleRate * bytesPerSample)

        millisecondsRounded = math.ceil(lengthInSeconds * 1000)
        return int(millisecondsRounded)
    except Exception as e:
        BLpython.BlPrint(str(e))
    return -1
BLpython.TSregisterFunc(None, None, "getOggLength", getOggLength, int, "Gets the millisecond length of a OGG Vorbis sound file.", 2, 2)